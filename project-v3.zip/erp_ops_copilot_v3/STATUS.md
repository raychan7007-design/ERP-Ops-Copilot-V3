# ERP Ops Copilot V3 状态

## 已完成（聊天模式）

- ERP 演示数据库与 MySQL 兼容结构设计
- 白名单参数化只读 SQL Tools + Join/参数 Trace
- 采购/销售异常诊断 + 检查链 + 建议动作
- Router Trace：规则命中原因可解释
- 本地 RAG + ERP 领域 Query Expansion + 来源证据
- UAT Assistant：正常 / 边界 / 非法 / 权限 / 幂等 / 一致性
- 本地 Web Demo + `/api/health` + `/api/query`
- Dockerfile / docker-compose / `.env.example`
- Dify OpenAPI、节点 Prompt、知识库清单、部署检查清单
- 架构图、Demo脚本、JD映射、简历候选描述、面试追问树

## V3 实测

- 自动化测试：**27/27 通过**
- 固定合成功能回归：**17/17 通过**
- RAG 合成检索回归：**Recall@1=100%，Recall@3=100%，MRR=1.000**
- 开发验证集：**32/32 Case 通过，48/48断言通过**
- V3 封存 Holdout：**29/29 Case 通过，Router 29/29，42/42断言通过**
- HTTP smoke：health 返回 `v3`；SO100 查询返回 `BLOCK`、缺口2件
- Python `compileall`：通过

> 所有数字均为本地、合成、作品集级回归。不是生产准确率、真实用户效果或第三方独立评测。

## 本轮发现并修复

开发验证首次执行前，generic UAT 模板存在参数数量错误，会在普通必填字段类需求上抛出 `TypeError`。已修复并增加单元回归；之后开发验证 32/32 通过。最终 Holdout 使用另一套新封存数据，首次完整执行 29/29 通过；完成后未再修改 V3 应用实现。

## 尚需外部环境

- 将 HTTP 服务部署到公网 HTTPS 地址（Dify Cloud 才能调用）
- Dify 网页真实创建应用、知识库与工作流
- 用户自己的模型 API Key / 登录 / 2FA
- Dify 环境下按 `docs/dify_acceptance_cases.md` 真机验收并截图
- GitHub 获取写权限后 commit / push
- Docker 容器实机 build（当前交付环境无 Docker CLI）
