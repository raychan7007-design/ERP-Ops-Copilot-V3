# ERP Ops Copilot｜企业ERP智能运维与实施支持 Agent

面向 **ERP实施 / 企业信息化 / 系统管理** 求职作品集的可运行项目。核心目标不是做一个“上传PDF然后聊天”的薄RAG，而是把 **非结构化业务规则 + 结构化ERP数据 + 异常诊断 + UAT辅助** 串成一条可解释工作流。

## 一句话架构

**用户问题 → Intent Router → RAG知识检索 / SQL只读Tool / 规则诊断 / UAT生成 → 证据化回答**

## 已实现（聊天模式已真实完成）

- SQLite ERP 演示库：商品、供应商、采购单/明细、销售单/明细、库存、库存流水。
- 参数化只读 SQL Tools：库存、PO、SO、库存流水、库存汇总。
- 采购诊断：待验收/部分验收/已完成、剩余验收量、来源流水。
- 销售诊断：库存不足拦截、可出库判断、来源流水。
- 离线 RAG：无需API Key，用本地 TF-IDF/余弦检索知识库并返回来源。
- UAT Assistant：按正常、边界、异常、数据一致性生成测试场景。
- 本地 Web Demo：仅Python标准库，浏览器直接使用。
- 自动化单元/端到端测试与固定功能评测。
- Dify 节点、Prompt、知识库上传清单已经设计好，**尚未在Dify网页实际部署**。

## 快速运行

要求 Python 3.10+，核心功能不需要安装第三方包。

```bash
python scripts/build_db.py
python main.py "PO100为什么还是部分验收？"
python scripts/demo.py
python -m unittest discover -s tests -v
python scripts/evaluate.py
```

启动网页：

```bash
python -m app.web
```

浏览器打开 `http://127.0.0.1:8000`。

## 推荐Demo问题

- `PO100为什么还是部分验收？`
- `SO100为什么不能出库？`
- `SKU002现在库存多少，最近发生了什么？`
- `为什么库存余额还需要库存流水？`
- `新增分批验收功能，允许多次到货但累计不得超过采购数量，怎么做UAT？`

## 为什么这个项目不是普通RAG

普通RAG只能回答文档问题。本项目把问题分成：

1. **规则/流程问题** → RAG；
2. **实时业务事实** → SQL Tool；
3. **异常定位** → SQL事实 + 业务规则；
4. **需求验收** → UAT生成。

同时限制模型不能直接生成任意SQL执行，数据访问通过白名单参数化函数完成。

## 和已有项目的关系

- ERP Fit-Gap 提供业务规则、状态流转、异常和UAT思路；
- 智链进销存提供采购—库存—销售、SQL和库存流水的技术基础；
- ERP Ops Copilot 把两者进一步串成“实施 + 运维 + AI Agent”的完整展示。

## 真实性边界

这是 **独立模拟作品集**，数据均为演示数据：

- 不是真实客户项目；
- 不是真实SAP配置、生产上线或企业运维记录；
- SQLite 是本地可复现演示，`data/mysql_schema.sql` 是 MySQL 8.x 结构设计草案；
- 当前离线RAG不是生产级Embedding/RAG，也不声称等价于Dify部署；
- `outputs/evaluation.json` 是固定合成功能回归，不是模型准确率或真实用户效果。

## 外部工具还剩什么

聊天模式已把核心项目做成可运行版本。后续真正需要 Work/Dify 的只有：创建Dify应用、上传知识库、按 `dify/WORKFLOW_SPEC.md` 配节点以及填入用户自己的API Key。GitHub写入需要具备仓库写权限后再推送。

## V2 深化：可解释与可评测

在 V1 可运行基础上增加：

- **Router Trace**：每次回答说明为什么进入 RAG / SQL / 诊断 / UAT。
- **SQL Tool Trace**：返回调用 Tool、参数、涉及表与 Join 关系，便于审计和面试讲解。
- **诊断 Check List**：采购/销售诊断明确列出库存、数量、状态规则检查结果。
- **RAG Query Expansion**：增加少量 ERP 领域同义扩展，并返回 Top-K 分数、命中词和置信度。
- **RAG 回归评测**：`python scripts/evaluate_rag.py`，验证手工合成问法能否命中预期知识章节。
- **UAT Coverage**：输出需求类型、覆盖维度、场景焦点，并新增幂等/重复提交测试。

> 所有评测继续坚持“合成回归 ≠ 生产准确率”的边界。

## V3 封版工程化

在 V2 的可解释工作流基础上，V3 不再继续堆功能，而是补齐“可部署、可验收、可面试”的工程化材料：

- Dockerfile / docker-compose / `.env.example`；
- 可配置 HTTP Host / Port 与输入长度校验；
- Dify OpenAPI Tool 定义、Router/Answer Prompt、部署检查清单；
- Mermaid 架构图、Dify 真机验收 Case、面试追问树；
- 新增通用 UAT 场景回归，修复 generic UAT 输入时的参数错误；
- 开发验证集 32/32 通过；
- **开发验证完成后另行封存的 V3 Holdout：29/29 Case 通过，Router 29/29，结构/内容断言 42/42。**

Holdout 文件在 `evaluation/holdout_cases_v3.json`，SHA256 固化于 `evaluation/holdout_protocol_v3.json`。该指标只说明这套合成 ERP 作品集场景在当前固定规则和演示数据上通过，不是生产准确率、真实企业泛化能力或第三方测评。

### Docker 运行

```bash
docker build -t erp-ops-copilot .
docker run --rm -p 8000:8000 erp-ops-copilot
```

也可：

```bash
docker compose up --build
```

> 当前交付环境未提供 Docker CLI，因此 Dockerfile 已生成，但本次没有声称完成容器实机 build；Python 本地启动与 HTTP smoke test 已真实通过。
